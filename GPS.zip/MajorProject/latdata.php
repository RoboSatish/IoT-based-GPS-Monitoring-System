
<html lang="">

<head>
<title>Vehicle Tracking-Latitude</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">

<div class="wrapper row1">
  <header id="header" class="hoc clear">
    <div id="logo" class="fl_left"> 
     
      <h1 class="logoname"><a href="index.html">Acquiring <span>L</span>atitude <span>C</span>o-ordinate </a></h1>
      </br> </br> 
      <h1>Please Wait.......! </h1> 
	  </br></br></br></br>  
      
    </div>
    <nav id="mainav" class="fl_right"> 
    
   
    </nav>
  </header>
</div>

<?php
include "connect.php";
$url = "https://api.thingspeak.com/channels/1714109/feeds.xml?results=2";
$xml = simplexml_load_file($url);
$field1 = $xml->xpath('//feed/field1'); 
foreach ($field1 as $r1)
//echo $r1; 
//echo "<meta http-equiv='refresh' content='5' />";
/*
$field2 = $xml->xpath('//feed/field2'); 
foreach ($field2 as $r2)
echo $r2;
*/
date_default_timezone_set("Asia/Kolkata");
$t1=date("Y/m/d h:i:sa");

$sql = "INSERT INTO vehicle (ID,Date,Latitude) VALUES ('','$t1','$r1')";

if ($conn->query($sql) === TRUE) 
{
    
  
    echo "</br>";
  //echo "Sensor Values Inserted successfully";
 // echo"<script>window.open('welcome.php','_self')</script>";
} else
	{
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
echo "<meta http-equiv='refresh' content='10' />";
?>
