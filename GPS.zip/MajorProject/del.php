
<html lang="">

<head>
<title>Vehicle Tracking-Longitude</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<body id="top">

<div class="wrapper row1">
  <header id="header" class="hoc clear">
    <div id="logo" class="fl_left"> 
     
      <h1 class="logoname"><a href="index.html">Deleting <span>A</span>ll <span>R</span>ecord </a></h1>
      </br> </br> 
      <h1>Please Wait.......! </h1> 
      
      	<div class="nav">
	<a href="index.html"> Click toGo Home</a> </div>
	  </br></br></br></br>  
      
    </div>
    <nav id="mainav" class="fl_right"> 
    
   
    </nav>
  </header>
</div>

<?php
//including the database connection file
include_once("connect.php");

//$conn1 = mysqli_query($conn, "DELETE vehicle.ID,vehicle.Date, vehicle.Latitude,vehicle1.ID,vehicle1.Date, vehicle1.Logitude  FROM vehicle, vehicle1 ");// ORDER BY id ASC
//$conn1 = mysqli_query($conn, "DELETE  FROM vehicle");// ORDER BY id ASC
$conn1 = "DELETE FROM vehicle";
if ($conn->query($conn1) === TRUE) {
  //echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $conn->error;
}



$conn2 = "DELETE FROM vehicle1";
if ($conn->query($conn2) === TRUE) {
 // echo "Record deleted successfully...";
} else {
  echo "Error deleting record: " . $conn->error;
}


$conn->close();

?>


