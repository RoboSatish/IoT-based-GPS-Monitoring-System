

<?php
//including the database connection file
include_once("connect.php");
//$conn1 = mysqli_query($conn, "SELECT * FROM vehicle where Latitude	 !='' ");// ORDER BY id ASC
$conn1 = mysqli_query($conn, "SELECT vehicle.ID,vehicle.Date, vehicle.Latitude, vehicle1.Longitude FROM vehicle, vehicle1 where vehicle.Latitude!='' AND vehicle1.Longitude !='' ORDER BY vehicle.ID DESC");// ORDER BY id ASC
//$conn1 = mysqli_query($conn, "SELECT * FROM vehicle");// ORDER BY id ASC

?>

<html>
<head>
	<title>History</title>
	<link href = "css/bootstrap.min.css" rel = "stylesheet">
      <link href = "css/bootstrap.css" rel = "stylesheet">
      <script src="js/jquery-3.4.1.js"></script> 
      <style type="text/css">
      	body{
		
       background-image: url("images/bg3.jpg");
       background-size: cover;
	
	}
	.table_content{
		padding-top: 3px;
	}
	.nav{
		float: right;
		margin-right: 30px;
	}
      </style>
	
</head>

<body>
   
	 <h2 style="color: #F39C12" align="center"><b>All History</b></h2> 
	  <button onClick="window.location.reload();" align="center">Refresh Page</button>
	<div class="nav">
	<a href="index.html">Home</a> </div>
	<br/><br/>
	<div class="container table_content">
<table class="table table-striped table-light">
  <thead>
    <tr class="bg-warning">
      <th scope="col">Id</th>
      <th scope="col">Date</th>
      <th scope="col">Longitude</th>
      <th scope="col">Latitude</th>
        <th scope="col">GoTo Map</th>
     
    
     
	  
    </tr>
  </thead>
		<?php
		while($res = mysqli_fetch_array($conn1)) {		
			echo "<tr>";
			
			$y1=$res['Latitude'];
			$y2=$res['Longitude'];
				$y3=$res['ID'];
			echo "<td>  VTSID2022$y3 </td>";
		//	echo "<td>".$res['ID']."</td>";
			echo "<td>".$res['Date']."</td>";
			echo "<td>".$res['Latitude']."</td>";	
			
			echo "<td>".$res['Longitude']."</td>";	
			//echo "<td>".$res['date1']."</td>";	
		echo	" <td><a href='https://maps.google.com/?q=$y1 $y2'> Click ToGo Map </a></td>";
			
		}
		
		
		
		?>
	</table>	</div>
	

</body>
</html>
