	

<?php
$servername = "localhost";
$username = "swayamte_gps123";
$password = "gps123";
$dbname = "swayamte_gps";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
else
{
   // echo "Successful";
}